if UpdateThisMod then
	UpdateThisMod:Add({
		mod_id = 'InGameWaitingStatusColor',
		data = {
			modworkshop_id = 19670,
			dl_url = "https://github.com/PJzuza/IGWSC/raw/master/updates/IGWSC.zip",
			info_url = "https://raw.githubusercontent.com/PJzuza/IGWSC/master/mod.txt"
		}
	})
end